import pytesseract
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

#stroe images in folder called "quotes" in current directory
dir = os.getcwd() + "/quotes/"
#loop through directory, if image -> convert to text
# -> write to txt file with same name as image
for filename in os.listdir(dir):
    if filename.endswith(".jpeg") or filename.endswith(".jpg") or filename.endswith(".png"):
        img2 = mpimg.imread(dir+filename)
        imgplot = plt.imshow(img2)
        plt.show()
        img = cv2.imread(dir+filename)
        text2 = pytesseract.image_to_string(img)
        new_file = open(dir+os.path.splitext(filename)[0]+".txt", "w")
        new_file.write(text2)
        new_file.close()