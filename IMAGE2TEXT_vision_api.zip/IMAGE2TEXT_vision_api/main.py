from google.cloud import vision_v1
from google.cloud.vision_v1 import types
import os
import io


os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = ###add key

#store images in folder called "quotes" in current directory
dir = os.getcwd() + "/quotes/"
#loop through directory, if image -> convert to text
# write to txt file with same name as image
for filename in os.listdir(dir):
    if filename.endswith(".jpeg") or filename.endswith(".jpg") or filename.endswith(".png"):
        content = io.open(dir+filename, 'rb').read()
        text2 = vision_v1.ImageAnnotatorClient().document_text_detection(image=vision_v1.types.Image(content=content)).full_text_annotation.text
        new_file = open(dir+os.path.splitext(filename)[0]+".txt", "w")
        new_file.write(text2)
        new_file.close()







