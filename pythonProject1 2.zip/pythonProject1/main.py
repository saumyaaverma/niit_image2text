import pytesseract
import cv2
import os
import matplotlib.pyplot as plt
import matplotlib.image as mpimg




x = 0
dir = "/Users/apple/PycharmProjects/pythonProject1/venv/quotes/"
for filename in os.listdir(dir):
    if filename.endswith(".jpeg") or filename.endswith(".jpg") or filename.endswith(".png"):
        img2 = mpimg.imread(dir+filename)
        imgplot = plt.imshow(img2)
        plt.show()
        img = cv2.imread(dir+filename)
        text2 = pytesseract.image_to_string(img)
        print("\nImage",x,"says:\n" + text2)
        x+=1



